#include "PrixJournalier.h"
#include "Date.h"
#include "PersistancePrixJournaliers.h"
#include<vector>
#include<iostream>
#include<fstream>
using namespace std;

int main(){
    string ch1;
    //PrixJournalier Pj;
    ch1="../prices_simple.csv";
	vector<PrixJournalier> vPj;
    PersistancePrixJournaliers ppj;
	vPj=ppj.lirePrixJournaliersDUnFichier(ch1);
    
    cout << vPj[0] << endl;
    cout << vPj[1] << endl;
    cout << vPj[2] << endl;
    return 0;
}
